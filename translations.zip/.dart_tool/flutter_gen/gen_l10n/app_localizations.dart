
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_ms.dart';
import 'app_localizations_zh.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations returned
/// by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// localizationDelegates list, and the locales they support in the app's
/// supportedLocales list. For example:
///
/// ```
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('ms'),
    Locale('zh')
  ];

  /// The Current Language
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get language;

  /// Appbar title for Home page
  ///
  /// In en, this message translates to:
  /// **'Home Page'**
  String get homePage;

  /// Text for button start ordering in Home page
  ///
  /// In en, this message translates to:
  /// **'Start ordering'**
  String get startOrdering;

  /// An instruction to scan QR Code
  ///
  /// In en, this message translates to:
  /// **'Scan QR code'**
  String get scanQrCode;

  /// A text for text button to show more info
  ///
  /// In en, this message translates to:
  /// **'More info'**
  String get moreInfo;

  /// A title text for a store Rating
  ///
  /// In en, this message translates to:
  /// **'Rating'**
  String get rating;

  /// A text for text button to show all reviews in ratings
  ///
  /// In en, this message translates to:
  /// **'View all Reviews'**
  String get viewAllReview;

  /// One of the category selections in menu
  ///
  /// In en, this message translates to:
  /// **'Popular'**
  String get popular;

  /// One of the category selection in menu
  ///
  /// In en, this message translates to:
  /// **'Breakfast'**
  String get breakfast;

  /// A text in button to review order
  ///
  /// In en, this message translates to:
  /// **'Review order'**
  String get reviewOrder;

  /// A text to expand the description in item
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get more;

  /// A text to collapse the description in item
  ///
  /// In en, this message translates to:
  /// **'Less'**
  String get less;

  /// Hint text for user to add special request if they want
  ///
  /// In en, this message translates to:
  /// **'Add if you have special request to restaurant'**
  String get addSpecialRequest;

  /// A text in button to add item into cart
  ///
  /// In en, this message translates to:
  /// **'Add to cart'**
  String get addToCart;

  /// A title text for showing order type
  ///
  /// In en, this message translates to:
  /// **'Order type'**
  String get orderType;

  /// One of the order type, another is Take away
  ///
  /// In en, this message translates to:
  /// **'Dine in'**
  String get dineIn;

  /// One of the order type, another is Dine in
  ///
  /// In en, this message translates to:
  /// **'Take away'**
  String get takeAway;

  /// To show table number
  ///
  /// In en, this message translates to:
  /// **'Table no.'**
  String get tableNo;

  /// To show number of items in cart
  ///
  /// In en, this message translates to:
  /// **'You have'**
  String get youHave;

  /// To show number of items in cart
  ///
  /// In en, this message translates to:
  /// **'item(s)'**
  String get items;

  /// Text in button Apply voucher
  ///
  /// In en, this message translates to:
  /// **'Apply voucher'**
  String get applyVoucher;

  /// Text below voucher text field. Show no voucher is redeemed
  ///
  /// In en, this message translates to:
  /// **'No voucher is redeemed'**
  String get voucherTextNoVoucher;

  /// Text below voucher text field. Show voucher entered is invalid
  ///
  /// In en, this message translates to:
  /// **'Invalid voucher'**
  String get voucherTextInvalidVoucher;

  /// Text below voucher text field. Show voucher has successfully redeemed
  ///
  /// In en, this message translates to:
  /// **'Voucher has successfully redeemed'**
  String get voucherTextVoucherRedeemed;

  /// Label to show subtotal of items in cart
  ///
  /// In en, this message translates to:
  /// **'Subtotal'**
  String get subtotal;

  /// Label to show Gov Tax of items in cart
  ///
  /// In en, this message translates to:
  /// **'Gov Tax ({govTaxPercentage}%)'**
  String govTax(String govTaxPercentage);

  /// Label to show Service Tax of items in cart
  ///
  /// In en, this message translates to:
  /// **'Service Tax ({serviceTaxPercentage}%)'**
  String serviceTax(String serviceTaxPercentage);

  /// Label to show discount amount of items in cart when voucher is applied
  ///
  /// In en, this message translates to:
  /// **'Voucher'**
  String get voucher;

  /// Label to show Net Total of items in cart
  ///
  /// In en, this message translates to:
  /// **'Net Total'**
  String get netTotal;

  /// Text in button Place order
  ///
  /// In en, this message translates to:
  /// **'Place order'**
  String get placeOrder;

  /// Text to inform customer the order is received and being prepared
  ///
  /// In en, this message translates to:
  /// **'We have received your order, we are preparing the order'**
  String get weHaveReceivedText;

  /// Title Text for order type, date, and table no
  ///
  /// In en, this message translates to:
  /// **'Order details'**
  String get orderDetails;

  /// Label text for date
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// Label text for button Add more order
  ///
  /// In en, this message translates to:
  /// **'Add more order'**
  String get addMoreOrder;

  /// Title text for order summary, shows orders in a list
  ///
  /// In en, this message translates to:
  /// **'Order Summary'**
  String get orderSummary;

  /// Label text for orders with customer's name
  ///
  /// In en, this message translates to:
  /// **'{name}\'s order'**
  String customersOrder(String name);

  /// Label text for showing the confirmation is pending
  ///
  /// In en, this message translates to:
  /// **'Pending confirmation'**
  String get pendingConfirmation;

  /// No description provided for @orderConfirmed.
  ///
  /// In en, this message translates to:
  /// **'Order confirmed'**
  String get orderConfirmed;

  /// Label text for mentioning the total in order summary is including tax and voucher discount
  ///
  /// In en, this message translates to:
  /// **'Total incl. tax & discount'**
  String get totalInclude;

  /// Text to inform user voucher is not available in Order Summary page
  ///
  /// In en, this message translates to:
  /// **'Sorry, selected voucher is not available for this order'**
  String get voucherNotAvailableText;

  /// Text next to check box, to show number of orders selected in order detail page
  ///
  /// In en, this message translates to:
  /// **'Selected {orderCount} order(s)'**
  String orderSelected(String orderCount);

  /// Label Text to show total payment in order detail page
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get total;

  /// Label text to show total discount for payment in order detail page
  ///
  /// In en, this message translates to:
  /// **'Discount'**
  String get discount;

  /// Text for button to pay now
  ///
  /// In en, this message translates to:
  /// **'Pay Now'**
  String get payNow;

  /// Text below the button pay now, customer can choose to pay later
  ///
  /// In en, this message translates to:
  /// **'I will pay my bill later'**
  String get payLater;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['en', 'ms', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en': return AppLocalizationsEn();
    case 'ms': return AppLocalizationsMs();
    case 'zh': return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
