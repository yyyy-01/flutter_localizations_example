


import 'app_localizations.dart';

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get language => '简体中文';

  @override
  String get homePage => '主页';

  @override
  String get startOrdering => '开始点单';

  @override
  String get scanQrCode => '扫描二维码';

  @override
  String get moreInfo => '了解更多';

  @override
  String get rating => '评分';

  @override
  String get viewAllReview => '查看所有评论';

  @override
  String get popular => '流行';

  @override
  String get breakfast => '早餐';

  @override
  String get reviewOrder => '查看订单';

  @override
  String get more => '展开';

  @override
  String get less => '收起';

  @override
  String get addSpecialRequest => '如果您对餐厅有特殊要求，请添加';

  @override
  String get addToCart => '添加到购物车';

  @override
  String get orderType => '订单类型';

  @override
  String get dineIn => '堂食';

  @override
  String get takeAway => '外带';

  @override
  String get tableNo => '桌号';

  @override
  String get youHave => '您有';

  @override
  String get items => '件商品';

  @override
  String get applyVoucher => '使用兑换券';

  @override
  String get voucherTextNoVoucher => '未使用兑换券';

  @override
  String get voucherTextInvalidVoucher => '兑换卷无效';

  @override
  String get voucherTextVoucherRedeemed => '已使用兑换券';

  @override
  String get subtotal => '小计';

  @override
  String govTax(String govTaxPercentage) {
    return '政府税 ($govTaxPercentage%)';
  }

  @override
  String serviceTax(String serviceTaxPercentage) {
    return '服务税 ($serviceTaxPercentage%)';
  }

  @override
  String get voucher => '兑换券';

  @override
  String get netTotal => '总值';

  @override
  String get placeOrder => '下单';

  @override
  String get weHaveReceivedText => '我们已收到您的订单，我们正在准备此订单';

  @override
  String get orderDetails => '订单详细信息';

  @override
  String get date => '日期';

  @override
  String get addMoreOrder => '添加更多订单';

  @override
  String get orderSummary => '订单总结';

  @override
  String customersOrder(String name) {
    return '$name的订单';
  }

  @override
  String get pendingConfirmation => '等待确认';

  @override
  String get orderConfirmed => '订单已确认';

  @override
  String get totalInclude => '总计含税和折扣';

  @override
  String get voucherNotAvailableText => '抱歉，所选兑换券不适用于此订单';

  @override
  String orderSelected(String orderCount) {
    return '已选 $orderCount 个订单';
  }

  @override
  String get total => '总价';

  @override
  String get discount => '折扣';

  @override
  String get payNow => '立即支付';

  @override
  String get payLater => '我稍后会付帐';
}
