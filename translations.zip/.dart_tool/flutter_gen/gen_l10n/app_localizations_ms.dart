


import 'app_localizations.dart';

/// The translations for Malay (`ms`).
class AppLocalizationsMs extends AppLocalizations {
  AppLocalizationsMs([String locale = 'ms']) : super(locale);

  @override
  String get language => 'Bahasa Malaysia';

  @override
  String get homePage => 'Laman utama';

  @override
  String get startOrdering => 'Mula memesan';

  @override
  String get scanQrCode => 'Imbas Kod QR';

  @override
  String get moreInfo => 'Maklumat lanjut';

  @override
  String get rating => 'Penilaian';

  @override
  String get viewAllReview => 'Lihat Semua Ulasan';

  @override
  String get popular => 'Popular';

  @override
  String get breakfast => 'Sarapan pagi';

  @override
  String get reviewOrder => 'Semakan pesanan';

  @override
  String get more => 'Lebih';

  @override
  String get less => 'Kurang';

  @override
  String get addSpecialRequest => 'Tambah jika anda mempunyai permintaan khas ke restoran';

  @override
  String get addToCart => 'Tambah ke troli';

  @override
  String get orderType => 'Jenis pesanan';

  @override
  String get dineIn => 'Makan sini';

  @override
  String get takeAway => 'Bawa pulang';

  @override
  String get tableNo => 'Meja no.';

  @override
  String get youHave => 'Kamu ada';

  @override
  String get items => 'item';

  @override
  String get applyVoucher => 'Tebus baucar';

  @override
  String get voucherTextNoVoucher => 'Tiada baucar ditebus';

  @override
  String get voucherTextInvalidVoucher => 'Baucar tidak sah';

  @override
  String get voucherTextVoucherRedeemed => 'Baucar telah berjaya ditebus';

  @override
  String get subtotal => 'Jumlah Kecil';

  @override
  String govTax(String govTaxPercentage) {
    return 'Cukai Kerajaan ($govTaxPercentage%)';
  }

  @override
  String serviceTax(String serviceTaxPercentage) {
    return 'Cukai Perkhidmatan ($serviceTaxPercentage%)';
  }

  @override
  String get voucher => 'Baucar';

  @override
  String get netTotal => 'Jumlah Bersih';

  @override
  String get placeOrder => 'Pesan';

  @override
  String get weHaveReceivedText => 'Kami telah menerima tempahan anda, kami sedang menyediakan tempahan';

  @override
  String get orderDetails => 'Maklumat-maklumat Pesanan';

  @override
  String get date => 'Tarikh';

  @override
  String get addMoreOrder => 'Tambah lagi Pesanan';

  @override
  String get orderSummary => 'Rumusan Pesanan';

  @override
  String customersOrder(String name) {
    return 'Pesanan $name';
  }

  @override
  String get pendingConfirmation => 'Menunggu pengesahan';

  @override
  String get orderConfirmed => 'Pesanan disahkan';

  @override
  String get totalInclude => 'Jumlah termasuk cukai & diskaun';

  @override
  String get voucherNotAvailableText => 'Maaf, baucar yang dipilih tidak tersedia untuk pesanan ini';

  @override
  String orderSelected(String orderCount) {
    return '$orderCount pesanan dipilih';
  }

  @override
  String get total => 'Jumlah';

  @override
  String get discount => 'Diskaun';

  @override
  String get payNow => 'Bayar sekarang';

  @override
  String get payLater => 'Saya akan bayar bil kemudian';
}
