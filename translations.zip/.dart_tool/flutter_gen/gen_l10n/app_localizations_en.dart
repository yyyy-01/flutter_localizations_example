


import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get language => 'English';

  @override
  String get homePage => 'Home Page';

  @override
  String get startOrdering => 'Start ordering';

  @override
  String get scanQrCode => 'Scan QR code';

  @override
  String get moreInfo => 'More info';

  @override
  String get rating => 'Rating';

  @override
  String get viewAllReview => 'View all Reviews';

  @override
  String get popular => 'Popular';

  @override
  String get breakfast => 'Breakfast';

  @override
  String get reviewOrder => 'Review order';

  @override
  String get more => 'More';

  @override
  String get less => 'Less';

  @override
  String get addSpecialRequest => 'Add if you have special request to restaurant';

  @override
  String get addToCart => 'Add to cart';

  @override
  String get orderType => 'Order type';

  @override
  String get dineIn => 'Dine in';

  @override
  String get takeAway => 'Take away';

  @override
  String get tableNo => 'Table no.';

  @override
  String get youHave => 'You have';

  @override
  String get items => 'item(s)';

  @override
  String get applyVoucher => 'Apply voucher';

  @override
  String get voucherTextNoVoucher => 'No voucher is redeemed';

  @override
  String get voucherTextInvalidVoucher => 'Invalid voucher';

  @override
  String get voucherTextVoucherRedeemed => 'Voucher has successfully redeemed';

  @override
  String get subtotal => 'Subtotal';

  @override
  String govTax(String govTaxPercentage) {
    return 'Gov Tax ($govTaxPercentage%)';
  }

  @override
  String serviceTax(String serviceTaxPercentage) {
    return 'Service Tax ($serviceTaxPercentage%)';
  }

  @override
  String get voucher => 'Voucher';

  @override
  String get netTotal => 'Net Total';

  @override
  String get placeOrder => 'Place order';

  @override
  String get weHaveReceivedText => 'We have received your order, we are preparing the order';

  @override
  String get orderDetails => 'Order details';

  @override
  String get date => 'Date';

  @override
  String get addMoreOrder => 'Add more order';

  @override
  String get orderSummary => 'Order Summary';

  @override
  String customersOrder(String name) {
    return '$name\'s order';
  }

  @override
  String get pendingConfirmation => 'Pending confirmation';

  @override
  String get orderConfirmed => 'Order confirmed';

  @override
  String get totalInclude => 'Total incl. tax & discount';

  @override
  String get voucherNotAvailableText => 'Sorry, selected voucher is not available for this order';

  @override
  String orderSelected(String orderCount) {
    return 'Selected $orderCount order(s)';
  }

  @override
  String get total => 'Total';

  @override
  String get discount => 'Discount';

  @override
  String get payNow => 'Pay Now';

  @override
  String get payLater => 'I will pay my bill later';
}
